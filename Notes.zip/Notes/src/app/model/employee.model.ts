export class Employee {
    id: string;
    title: string;
    description: string;
    // code: string;
    // contactNumber: number;
    // address: string;
}
