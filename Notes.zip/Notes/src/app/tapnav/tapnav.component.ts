import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tapnav',
  templateUrl: './tapnav.component.html',
  styleUrls: ['./tapnav.component.css']
})
export class TapnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
